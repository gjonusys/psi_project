<?php

namespace App\Helpers;

use Exception;

class AuthHelper {
    public static function random_password(
        $length,
        $keyspace = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
    ) {
        $password = '';
        $max = mb_strlen($keyspace, '8bit') - 1;
        if ($max < 1) {
            throw new Exception('$keyspace must be at least two characters long');
        }
        for ($i = 0; $i < $length; ++$i) {
            $password .= $keyspace[random_int(0, $max)];
        }
        return $password;
    }
}