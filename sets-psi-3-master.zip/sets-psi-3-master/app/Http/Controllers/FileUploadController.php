<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Exception;
use \Illuminate\Database\QueryException;
use Illuminate\Support\Facades\Hash;
use App\Mail\WelcomeMail;
use Illuminate\Support\Facades\Mail;
use App\Models\User;
use App\Helpers\AuthHelper;

class FileUploadController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function fileUpload()
    {

        return view('room');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function fileUploadPost(Request $request)
    {
        $request->validate([
            'file' => 'required|file|mimes:csv,xls,ods,json|max:2000',
        ]);

        $content = $request->file->get();
        $students = json_decode($content);

        foreach ($students as &$student) {
            $student->password = AuthHelper::random_password(10);
        }

        try {
            User::insert(array_map(fn ($student) => $this->convertStudentToRecord($student), $students));
        } catch (QueryException $e) {
            return response(409);
        }
        foreach ($students as &$student) {
            Mail::to($student->email)->send(new WelcomeMail($student));
        }
        return response(200);
    }

    private function convertStudentToRecord($student)
    {
        return ([
            'name' => $student->firstname,
            'surname' => $student->lastname,
            'email' => $student->email,
            'password' => Hash::make($student->password),
            'role_id' => 3,
        ]);
    }
}
