#/bin/sh

composer install --prefer-dist --no-ansi --no-interaction --no-progress --no-scripts
composer update
php artisan key:generate

export NVM_DIR="$([ -z "${XDG_CONFIG_HOME-}" ] && printf %s "${HOME}/.nvm" || printf %s "${XDG_CONFIG_HOME}/nvm")"
[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"

npm i
npm run prod
