@extends('vendor/forum/master')
@section('title', 'Teams')
@section('main')
<div class="container">
    <div class="col-md-8 section offset-md-2">
        <teams-component :teams='{{ $teams }}'></teams-component>
    </div>
</div>

@endsection