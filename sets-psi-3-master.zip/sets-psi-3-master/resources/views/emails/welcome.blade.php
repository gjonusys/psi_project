<!DOCTYPE html>
<html>
<head>
    <title>Welcome Email</title>
</head>

<body>
<h2>Welcome to Noodle - SE Teaching Support System, {{$user['firstname']}}!</h2>
<br/>
Your registered email is {{$user['email']}}
Your temporary password is {{$user['password']}}
Please change it as soon as possible!
</body>

</html>