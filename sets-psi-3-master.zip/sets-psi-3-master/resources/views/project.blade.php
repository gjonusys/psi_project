@extends('vendor/forum/master')
@section('title', 'Project')
@section('main')

<project-component :auth_user='{{ $auth_user }}' :forum_threads='{{ $forum_threads }}'></project-component>

@endsection