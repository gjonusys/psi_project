@extends('vendor/forum/master')
@section('title', 'Welcome')
@section('main')
<welcome-component></welcome-component>
@endsection