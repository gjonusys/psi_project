@extends('vendor/forum/master')
@section('title', 'Groups')
@section('main')
<div class="container">
    <div class="col-md-8 section offset-md-2">
        <groups-component :groups='{{ $groups }}' :auth_user='{{ $auth_user }}'></groups-component>
    </div>
</div>

@endsection