<template>
  <div style="display: flex; align-items: center; flex-direction: column">
    <div
      style="
        display: flex;
        flex-grow: 1;
        justify-content: space-around;
        width: 55%;
        margin-bottom: 10px;
      "
    >
      <a type="submit" name="submit" class="btn btn-dark mt-4" href="/room">
        ← Back to Room
      </a>
      <a type="submit" name="submit" class="btn btn-dark mt-4" href="/groups">
        ← Back to Groups
      </a>
      <a
        type="submit"
        name="submit"
        class="btn btn-success mt-4"
        data-toggle="modal"
        data-target="#Modal"
        href="#"
      >
        Create Team
      </a>
    </div>
    <p v-if="allTeams.length != 0">Total Teams: <strong>{{ allTeams.length }}</strong></p>
    <p v-else>No Teams are created yet</p>
    <div style="display: flex; flex-direction: column">
      <a v-for="team in allTeams" :key="team.id" type="button" class="btn btn-primary" style="margin-top: 20px;  min-width: 350px;" :href="`/team/${team.id}`">{{ team.name }}</a>
    </div>
    <div
      class="modal fade"
      id="Modal"
      tabindex="-1"
      role="dialog"
      aria-labelledby="ModalLabel"
      aria-hidden="true"
    >
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="ModalLabel">Create Team</h5>
            <button
              type="button"
              class="close"
              data-dismiss="modal"
              aria-label="Close"
            >
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <div class="form-group">
              <label for="recipient-name" class="col-form-label"
                >Team Name:</label
              >
              <input type="text" class="form-control" id="name" ref="name" />
            </div>
          </div>
          <div class="modal-footer">
            <button
              type="button"
              class="btn btn-secondary"
              data-dismiss="modal"
            >
              Close
            </button>
            <button type="button" class="btn btn-success" @click="createTeam()" href="#">
              Create Team
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";

export default {
  props: ["teams", "user", "new_team"],

  data() {
    return {
      allTeams: this.teams,
    };
  },

  methods: {
    createTeam() {
      const data = {
        name: this.$refs.name.value,
      };
      axios
        .post("/teams", data)
        .then(() => location.reload())
        .catch((error) => {
          showNotification(error.response.data.message, "alert-danger");
        });
    },
  },
};
</script>

<style>
</style>
