<template>
  <div>
    <div class="jumbotron">
      <h1 class="display-4">{{ auth_user.name }} {{ auth_user.surname }}</h1>
      <div v-if="auth_user.project != undefined">
        <p class="lead">
          You have a project
          <strong>{{ auth_user.project.title }}</strong> assigned
        </p>
        <hr class="my-4" />
        <p>Go to your assigned project's page</p>
        <p class="lead">
          <a
            class="btn btn-primary btn-lg"
            :href="`/forum/t/${auth_user.project_id}-${auth_user.project.title}`"
            role="button"
            >{{ auth_user.project.title }}</a
          >
        </p>
      </div>
      <div v-else>
        <p class="lead">You don't have any project assigned yet</p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  props: ["auth_user", "forum_threads"],
};
</script>
<style>
a {
  background: none;
  color: inherit;
  border: none;
  padding: 0;
  font: inherit;
  cursor: pointer;
  outline: inherit;
}
</style>
