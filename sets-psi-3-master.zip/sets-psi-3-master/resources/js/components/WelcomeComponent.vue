<template>
  <div>
    <div class="jumbotron">
      <div class="container" style="text-align: center">
        <div>
          <img
            src="/img/noodle.png"
            alt="Noodle Logo"
            style="height: 200px; width: 200px"
          />
        </div>
        <h1 class="display-3" style="text-align: center">Welcome to Noodle!</h1>
        <p>
          A platform created for professors and students that wants simple,
          straightforward functionality and design. <strong>Login</strong> or
          <strong>Register</strong> to begin using our website!
        </p>
        <p>
          <a class="btn btn-primary btn-lg" href="/login" role="button"
            >Login</a
          >
          <a class="btn btn-primary btn-lg" href="/register" role="button"
            >Register</a
          >
        </p>
      </div>
    </div>

    <div class="container">
      <div class="row">
        <div class="col-md-4">
          <h2>Manage Students as a <strong>Professor</strong></h2>
          <p>
            <strong>Upload</strong> students' list,
            <strong>create</strong> groups, teams, <strong>rate</strong> your
            students' work, <strong>assign</strong> projects and
            <strong>discuss</strong> with students!
          </p>
        </div>
        <div class="col-md-4">
          <h2>
            Interact with colleagues and professors as a
            <strong>Student</strong>
          </h2>
          <p>
            Use a <strong>forum</strong> to discuss your ideas with your
            colleagues and professors. <strong>Offer</strong> project ideas,
            <strong>ask</strong> professors questions and
            <strong>view</strong> important information that professors provide
            for you. <strong>Form</strong> a team or <strong>join</strong> one.
          </p>
        </div>
        <div class="col-md-4">
          <h2>A platform for those who wants <strong>simplicity</strong></h2>
          <p>
            Our platform is created just for those who love
            <strong>simplicity</strong>. We provide <strong>intuitive</strong>,
            <strong>straightforward</strong> functionality and design.
          </p>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
</script>

<style>
</style>